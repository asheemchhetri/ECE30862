public class Derived extends Base {

   public Derived( ) { }

  // Add any needed function(s) here.
   public void f1(double num)
   {
	   System.out.println("Deriverd f1(float)");
   }
   public void f1()
   {
	   System.out.println("Base f1");
   }
}

