public class Derived extends Base {

   public Derived( ){   } //Constructor
   
   //add necessary function(s) here.
   //Base class overriding
   public void f2()
   {
	   System.out.println("Derived f2");
   }
}